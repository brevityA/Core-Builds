
## Audit rationale (already in this workspace)
`docs/AUDIT-2026-07-26.md` is the full audit record — methodology, a severity-ranked
finding → PR map, the roadmap/changelog staleness analysis, test totals, and the open
product-level follow-ups. It's included pre-applied so you can read it immediately.

If you'd rather carry it as its own tracked PR, apply the separate patch on `main`:
`git am <path>/Core-Builds-PR-audit-summary.patch` (docs-only, merge anytime). It is
intentionally NOT in `./patches/`, because `push-and-open-prs.sh` would otherwise try to
re-apply it on top of the already-present file.
